cd /home/appops/songyang1/netease-test/script/smoothbudget
source function.sh
cat offline_planid >smooth_cost_test1
md5sum smooth_cost_test1  > smooth_cost_test1.SUCCESS
hadoop fs -put -f smooth_cost_test1 smooth_cost_test1.SUCCESS /user/algo/rankserver/dicts/
