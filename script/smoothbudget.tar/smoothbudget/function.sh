#!/usr/bin/env bash

set -x

source ~/.bashrc
source ~/.profile

#alias beeline="/home/appops/hive/bin/beeline -u 'jdbc:hive2://hive1.jd.163.org:2181,hive2.jd.163.org:2181,spark5.jd.163.org:2181/;serviceDiscoveryMode=zooKeeper;zooKeeperNamespace=hive-cluster9;principal=hive/_HOST@HADOOP2.HZ.NETEASE.COM'"

_envDir=$(cd `dirname $0`; pwd)

source $_envDir/alarm.sh

userHome=`whoami`

if [ ! -z "$userHome" -a "$userHome" != " " ]; then
    echo "now user home is $userHome"
else
    userHome=lilonghua
fi

loginKT() {
    /usr/bin/kinit -kt /home/appops/hadoop/etc/hadoop/algo.keytab algo/dev@HADOOP.HZ.NETEASE.COM
}

#/usr/bin/kinit -kt /home/appops/hadoop/etc/hadoop/algo.keytab algo/dev@HADOOP.HZ.NETEASE.COM
loginKT

#hiveURL=jdbc:hive2://hive1.jd.163.org:2181,hive2.jd.163.org:2181,spark5.jd.163.org:2181/;serviceDiscoveryMode=zooKeeper;zooKeeperNamespace=hive-cluster9;principal=hive/_HOST@HADOOP2.HZ.NETEASE.COM

sleep_gap=20m
retries=5
sleep_retry=1m
tells="15810702615"
mails="lilonghua@corp.netease.com"

checkLocalFile() {
    if [ -e $1 ]; then
        return 0
    else
        return 1
    fi
}

checkHDFSFile() {
    hadoop fs -test -e $1

    if [ $? -eq 0 ]; then
        return 0
    else
        return 1
    fi
}

checkSuccess() {
    hadoop fs -test -e $1/_SUCCESS

    if [ $? -eq 0 ]; then
        return 0
    else
        return 1
    fi
}

checkHdfs() {
    count=`hdfs dfs -text $1/* | wc -l`

    if [ $count -gt 100 ]; then
        return 0
    else
        return 1
    fi
}

checkHdfsDir() {
    hdfs dfs -test -e $1

    if [ $? -eq 0 ]; then
        return 0
    else
        return 1
    fi
}

checkHive() {
    count=`hive -e "select count(*) from $1 where dt = '$2'" | tail -n 1`
    #count=`beeline -u 'jdbc:hive2://10.2.0.3:10000/default;principal=hive/bd-hadoop3-003.bj01.ocean.douyu.com@BJ01.OCEAN.DOUYU.COM' -e "select count(*) from $1 where dt = '$2'" | tail -n 2 | grep -Eo '[0-9]+' | tail -n 1`
    #count=`beeline -u "$hiveURL" -e "select count(*) from $1 where dt = '$2'" | tail -n 2 | grep -Eo '[0-9]+' | tail -n 1`

    if [ $count -gt 100 ]; then
        return 0
    else
        return 1
    fi
}

checkBeeline() {
    count=`/home/appops/hive/bin/beeline -u 'jdbc:hive2://hive1.jd.163.org:2181,hive2.jd.163.org:2181,spark5.jd.163.org:2181/;serviceDiscoveryMode=zooKeeper;zooKeeperNamespace=hive-cluster9;principal=hive/_HOST@HADOOP2.HZ.NETEASE.COM' -e "select count(*) from $1 where dt = '$2'" | tail -n 2 | grep -Eo '[0-9]+' | tail -n 1`
    #count=`beeline -e "select count(*) from $1 where dt = '$2'" | tail -n 2 | grep -Eo '[0-9]+' | tail -n 1`

    if [ $count -gt 100 ]; then
        return 0
    else
        return 1
    fi
}

hdfsPut() {
    hdfs dfs -put $1 $2

    if [ $? -eq 0 ]; then
        return 0
    else
        return 1
    fi
}

checkSuccessSleep () {
    checkSuccess $1
    s1=`echo $?`

    if test -n "$2"
    then
        checkSuccess $2
        s2=`echo $?`
    else
        s2=0
    fi

    flag=$[s1 + s2]

    while [[ $flag != 0 ]]; do
        sleep $sleep_gap
        loginKT
        checkSuccess $1
        s1=`echo $?`

        if [ $s2 != 0 ]; then
            checkSuccess $2
            s2=`echo $?`
        fi

        flag=$[s1 + s2]
    done
}

checkSuccessRetry () {
    loginKT
    checkSuccess $1
    s1=`echo $?`

    if test -n "$2"
    then
        loginKT
        checkSuccess $2
        s2=`echo $?`
    else
        s2=0
    fi

    flag=$[s1 + s2]
    retry=0

    while [[ $retry < $retries ]]; do
        if [ $flag -eq 0 ]; then
            return 0
        else
            retry=$[1 + retry]
            sleep $sleep_gap
            loginKT
            checkSuccess $1
            s1=`echo $?`

            if [ $s2 != 0 ]; then
                loginKT
                checkSuccess $2
                s2=`echo $?`
            fi

            flag=$[s1 + s2]
        fi
    done

    if [ $retry -ge $retries ]; then
        alarm_email $mails "RankModel Alarm for hdfs test file $1\t$2 check fails retries more than $retry"
    fi
}

checkHdfsSleep () {
    checkHdfs $1
    s1=`echo $?`

    if test -n "$2"
    then
        checkHdfs $2
        s2=`echo $?`
    else
        s2=0
    fi

    flag=$[s1 + s2]

    while [[ $flag != 0 ]]; do
        sleep $sleep_gap
        checkHdfs $1
        s1=`echo $?`

        if [ $s2 != 0 ]; then
            checkHdfs $2
            s2=`echo $?`
        fi

        flag=$[s1 + s2]
    done
}

checkHdfsDirSleep () {
    checkHdfsDir $1
    s1=`echo $?`

    if test -n "$2"
    then
        checkHdfsDir $2
        s2=`echo $?`
    else
        s2=0
    fi

    flag=$[s1 + s2]

    while [[ $flag != 0 ]]; do
        sleep $sleep_gap
        loginKT
        checkHdfsDir $1
        s1=`echo $?`

        if [ $s2 != 0 ]; then
            checkHdfsDir $2
            s2=`echo $?`
        fi

        flag=$[s1 + s2]
    done
}

checkHiveSleep () {
    loginKT
    checkHive $1 $2
    flag=`echo $?`
    while [[ $flag != 0 ]]; do
        sleep $sleep_gap
        loginKT
        checkHive $1 $2
        flag=`echo $?`
    done
}

checkHiveRetry () {
    retry=0

    while [[ $retry < $retries ]]; do
        loginKT
        checkHive $1 $2
        if [ $? -eq 0 ]; then
            return 0
        else
          retry=$[1 + retry]
          sleep $sleep_gap
        fi
    done

    if [ $retry -ge $retries ]; then
        alarm_email $mails "RankModel Alarm for hdfs file $1\t$2 check fails retries more than $retry"
    fi
}

checkBeelineSleep () {
    checkBeeline $1 $2
    flag=`echo $?`
    while [[ $flag != 0 ]]; do
        sleep $sleep_gap
        loginKT
        checkBeeline $1 $2
        flag=`echo $?`
    done
}

hdfsPutSafe () {
    if test -n "$1"
    then
        if test -n "$2"; then
            retry=0
         else
            retry=-1
        fi
    else
        retry=-1
    fi
    
    if [ $retry -lt 0 ]; then
        return 1
    fi

    while [[ $retry < $retries ]]; do
        hdfsPut $1 $2
        if [ $? -eq 0 ]; then
            return 0
        else
          retry=$[1 + retry]
          sleep $sleep_retry
        fi
    done

    if [ $retry -ge $retries ]; then
        #alarm_sms $tells "RankModel Alarm sms with put hdfs file retries $retry"
        alarm_email $mails "RankModel Alarm for hdfs put file $1 to $2 fails retries more than $retry"
    fi
}

getLastPartition () {
    #beeline -u 'jdbc:hive2://10.2.0.3:10000/default;principal=hive/bd-hadoop3-003.bj01.ocean.douyu.com@BJ01.OCEAN.DOUYU.COM' -e "show partitions $1" | tail -n 2 | grep -Eo '[0-9]+' | tail -n 1
    hive -e "select count(*) from $1 where dt = '$2'" | grep -Eo '[0-9]+' | tail -n 1
}

getLastData () {
    hdfs dfs -ls $1 | tail -n 2 | grep -Eo '[0-9]+' | tail -n 1
}